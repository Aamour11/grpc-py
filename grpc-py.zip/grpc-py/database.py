from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()
engine = create_engine('sqlite:///products.db', echo=True)
Session = sessionmaker(bind=engine)

class ProductModel(Base):
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(String(200))
    price = Column(Float)
    stock = Column(Integer)

Base.metadata.create_all(engine)

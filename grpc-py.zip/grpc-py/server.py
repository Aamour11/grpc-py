import grpc
from concurrent import futures
import product_pb2
import product_pb2_grpc
from database import Session, ProductModel

class ProductService(product_pb2_grpc.ProductServiceServicer):
    def CreateProduct(self, request, context):
        session = Session()
        try:
            product = ProductModel(
                name=request.name,
                description=request.description,
                price=request.price,
                stock=request.stock
            )
            session.add(product)
            session.commit()
            return product_pb2.ProductResponse(
                success=True,
                message=f"Product created with ID: {product.id}"
            )
        except Exception as e:
            session.rollback()
            return product_pb2.ProductResponse(success=False, message=str(e))
        finally:
            session.close()

    def ReadProduct(self, request, context):
        session = Session()
        try:
            product = session.query(ProductModel).filter_by(id=request.id).first()
            if product:
                return product_pb2.Product(
                    id=product.id,
                    name=product.name,
                    description=product.description,
                    price=product.price,
                    stock=product.stock
                )
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details('Product not found')
            return product_pb2.Product()
        finally:
            session.close()

    def UpdateProduct(self, request, context):
        session = Session()
        try:
            product = session.query(ProductModel).filter_by(id=request.id).first()
            if product:
                product.name = request.name
                product.description = request.description
                product.price = request.price
                product.stock = request.stock
                session.commit()
                return product_pb2.ProductResponse(
                    success=True,
                    message=f"Product {request.id} updated successfully"
                )
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details('Product not found')
            return product_pb2.ProductResponse(success=False, message="Product not found")
        except Exception as e:
            session.rollback()
            return product_pb2.ProductResponse(success=False, message=str(e))
        finally:
            session.close()

    def DeleteProduct(self, request, context):
        session = Session()
        try:
            product = session.query(ProductModel).filter_by(id=request.id).first()
            if product:
                session.delete(product)
                session.commit()
                return product_pb2.ProductResponse(
                    success=True,
                    message=f"Product {request.id} deleted successfully"
                )
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details('Product not found')
            return product_pb2.ProductResponse(success=False, message="Product not found")
        except Exception as e:
            session.rollback()
            return product_pb2.ProductResponse(success=False, message=str(e))
        finally:
            session.close()

    def ListProducts(self, request, context):
        session = Session()
        try:
            products = session.query(ProductModel).all()
            return product_pb2.ProductList(products=[
                product_pb2.Product(
                    id=p.id,
                    name=p.name,
                    description=p.description,
                    price=p.price,
                    stock=p.stock
                ) for p in products
            ])
        finally:
            session.close()

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    product_pb2_grpc.add_ProductServiceServicer_to_server(ProductService(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server started on port 50051")
    server.wait_for_termination()

if __name__ == '__main__':
    serve()

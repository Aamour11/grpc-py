import grpc
import product_pb2
import product_pb2_grpc

def run():
    channel = grpc.insecure_channel('localhost:50051')
    stub = product_pb2_grpc.ProductServiceStub(channel)

    # List All Products
    product_list = stub.ListProducts(product_pb2.Empty())
    print("All products:")
    for product in product_list.products:
        print(f"- ID: {product.id}, Name: {product.name}, Description: {product.description}, Price: {product.price}, Stock: {product.stock}")

if __name__ == '__main__':
    run()

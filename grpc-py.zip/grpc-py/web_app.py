from flask import Flask, render_template, request, redirect, url_for, flash
import grpc
import product_pb2
import product_pb2_grpc

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Tambahkan secret key untuk flash messages
channel = grpc.insecure_channel('localhost:50051')
stub = product_pb2_grpc.ProductServiceStub(channel)

@app.route('/')
def index():
    products = stub.ListProducts(product_pb2.Empty()).products
    return render_template('index.html', products=products)

@app.route('/add', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        try:
            product = product_pb2.Product(
                name=request.form['name'],
                description=request.form['description'],
                price=float(request.form['price']),
                stock=int(request.form['stock'])
            )
            response = stub.CreateProduct(product)
            if response.success:
                flash('Produk berhasil ditambahkan!', 'success')
            else:
                flash('Gagal menambahkan produk: ' + response.message, 'error')
        except ValueError:
            flash('Input tidak valid. Pastikan semua field diisi dengan benar.', 'error')
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_product(id):
    if request.method == 'POST':
        try:
            product = product_pb2.Product(
                id=id,
                name=request.form['name'],
                description=request.form['description'],
                price=float(request.form['price']),
                stock=int(request.form['stock'])
            )
            response = stub.UpdateProduct(product)
            if response.success:
                flash('Produk berhasil diperbarui!', 'success')
            else:
                flash('Gagal memperbarui produk: ' + response.message, 'error')
        except ValueError:
            flash('Input tidak valid. Pastikan semua field diisi dengan benar.', 'error')
        return redirect(url_for('index'))
    
    product = stub.ReadProduct(product_pb2.ProductId(id=id))
    return render_template('edit.html', product=product)

@app.route('/delete/<int:id>')
def delete_product(id):
    response = stub.DeleteProduct(product_pb2.ProductId(id=id))
    if response.success:
        flash('Produk berhasil dihapus!', 'success')
    else:
        flash('Gagal menghapus produk: ' + response.message, 'error')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
